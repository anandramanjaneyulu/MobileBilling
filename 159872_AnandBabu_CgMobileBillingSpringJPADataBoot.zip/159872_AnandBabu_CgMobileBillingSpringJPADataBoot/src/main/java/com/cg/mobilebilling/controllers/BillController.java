package com.cg.mobilebilling.controllers;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.GeneratePdfReport;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@Controller
public class BillController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/mobileBillGeneration")
	public ModelAndView generateMonthlyMobileBill(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("mobileBillPage","bill",bill);
	}
	@RequestMapping("/mobileBillDetails")
	public ModelAndView getmobileBillDetails(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException, FileNotFoundException, DocumentException  {
		Bill bill = billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		Document document = new Document();
		PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:\\AnandBabu\\Bill.pdf"));
		document.open();
		document.add(new Paragraph("Customer Id: "+customerID));
		document.add(new Paragraph("mobileNo : "+mobileNo));
		document.add(new Paragraph("Bill Month: "+billMonth));
		document.add(new Paragraph("localSMSAmount: "+bill.getLocalSMSAmount()));
		document.add(new Paragraph("StdSMSAmount: "+customerID));
		document.add(new Paragraph("LocalCallAmount: "+customerID));
		document.add(new Paragraph("StdCallAmount: "+customerID));
		document.add(new Paragraph("InternetDataUsageAmount: "+customerID));	
		document.add(new Paragraph("cgst: "+customerID));	
		document.add(new Paragraph("sgst: "+customerID));	
		document.add(new Paragraph("TotalBillAmount: "+customerID));	
		document.close();
		writer.close();

		return new ModelAndView("mobileBillDetailsPage","bill",bill);
	}
	@RequestMapping("/getAllBillDetails")
	public ModelAndView getmobileAllBillDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException {
		List<Bill> bills = billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		return new ModelAndView("mobileAllBillDetailsPage","bills",bills);
	}
	@RequestMapping(value = "/allBillsPdfReport", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_PDF_VALUE )
	public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException {

		List<Bill> bills =  billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);

		ByteArrayInputStream bis = GeneratePdfReport.billsReport(bills);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
}